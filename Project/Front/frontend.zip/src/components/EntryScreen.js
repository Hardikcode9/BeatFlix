import { useState } from "react"; 
import logo from "../assets/images/logo.png";
import {
  FaArrowRight, FaCompass, FaUserPlus, FaUserShield,
  FaEye, FaEyeSlash, FaGoogle, FaUser, FaEnvelope, FaLock
} from "react-icons/fa";

import "../styles/EntryScreen.css";
import { auth, googleProvider } from "../firebase/firebase";
import { signInWithPopup } from "firebase/auth";
import { toast } from "react-toastify";

// 3D Imports

function EntryScreen({ onEnter }) {
  // --- YOUR EXACT STATE ---
  const [formType, setFormType] = useState("");
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [confirmPassword, setConfirmPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirmPassword, setShowConfirmPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [message, setMessage] = useState("");
  const [showSuccess, setShowSuccess] = useState(false);
  const [showOtpModal, setShowOtpModal] = useState(false);
  const [otp, setOtp] = useState("");
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotEmail, setForgotEmail] = useState("");

  // --- YOUR EXACT AUTH LOGIC ---
  const handleGoogleLogin = async () => {
    try {
      const result = await signInWithPopup(auth, googleProvider);
      const firebaseUser = result.user;
      const response = await fetch(`${process.env.REACT_APP_API_URL}/api/users/google-login`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          name: firebaseUser.displayName, email: firebaseUser.email,
          avatar: firebaseUser.photoURL, googleId: firebaseUser.uid,
        }),
      });
      const data = await response.json();
      if (!response.ok) { setMessage(data.message); return; }
      localStorage.setItem("token", data.token);
      localStorage.setItem("user", JSON.stringify(data.user));
      onEnter(data.user.name);
    } catch (error) { console.error(error); setMessage("Google login failed."); }
  };

  const verifyAndRegister = async () => {
    try {
      setLoading(true); setMessage("");
      const otpResponse = await fetch(`${process.env.REACT_APP_API_URL}/api/users/verify-otp`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: email.trim(), otp }),
      });
      const otpData = await otpResponse.json();
      if (!otpResponse.ok) { setMessage(otpData.message); setLoading(false); return; }

      const registerResponse = await fetch(`${process.env.REACT_APP_API_URL}/api/users/register`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name: name.trim(), email: email.trim(), password, confirmPassword }),
      });
      const registerData = await registerResponse.json();
      if (!registerResponse.ok) { setMessage(registerData.message); setLoading(false); return; }

      setLoading(false); setShowOtpModal(false); setShowSuccess(true);
      toast.success("🎉 Profile created successfully!");
      setTimeout(() => {
        setShowSuccess(false); setFormType("login"); setName(""); setEmail("");
        setPassword(""); setConfirmPassword(""); setOtp(""); setMessage("");
      }, 2200);
    } catch (error) { console.error(error); setLoading(false); setMessage("Something went wrong."); }
  };

  const sendForgotOtp = async () => {
    try {
      setLoading(true); setMessage("");
      const response = await fetch(`${process.env.REACT_APP_API_URL}/api/users/forgot-password`, {
        method: "POST", headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email: forgotEmail.trim() }),
      });
      const data = await response.json();
      if (!response.ok) { setMessage(data.message); setLoading(false); return; }
      setLoading(false); toast.success("📩 OTP sent successfully!");
    } catch (error) { console.error(error); setLoading(false); setMessage("Failed to send OTP."); }
  };

  const submitForm = async (event) => {
    setLoading(true); event.preventDefault();
    if (!name.trim() || !password.trim()) { setMessage("Please fill in all required fields."); setLoading(false); return; }
    
    if (formType === "signup") {
      setMessage("");
      if (password !== confirmPassword) { setMessage("Passwords do not match."); setLoading(false); return; }
      try {
        const response = await fetch(`${process.env.REACT_APP_API_URL}/api/users/send-otp`, {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email: email.trim() }),
        });
        const data = await response.json();
        if (!response.ok) { setMessage(data.message || "Failed to send OTP."); setLoading(false); return; }
        setLoading(false); setShowOtpModal(true);
      } catch (error) { console.error("Signup Error:", error); setMessage("Could not connect to the BeatFlix server."); setLoading(false); }
      return;
    }
    
    if (formType === "login") {
      try {
        setMessage("");
        const response = await fetch(`${process.env.REACT_APP_API_URL}/api/users/login`, {
          method: "POST", headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ login: name.trim(), password }),
        });
        const data = await response.json();
        if (!response.ok) { setMessage(data.message || "Could not log in."); setLoading(false); return; }
        localStorage.setItem("token", data.token); localStorage.setItem("user", JSON.stringify(data.user));
        setLoading(false); toast.success(`👋 Welcome back, ${data.user.name}!`); onEnter(data.user.name);
      } catch (error) { console.error("Login Error:", error); setMessage("Could not connect to the BeatFlix server."); setLoading(false); }
    }
  };

  return (
    <main className="beatflix-entry-wrapper">

      {/* 2. SECURE HTML UI OVERLAY */}
      <div className="ui-overlay-container">
        <section className="entry-content">
          {!formType ? (
            <div className="netflix-entry">
              <div className="entry-brand">
                <div className="entry-brand-icon"><img src={logo} alt="BeatFlix" /></div>
                <div className="entry-brand-name"><span className="brand-white">Beat</span><span className="brand-blue">Flix</span></div>
              </div>
              <h1 className="who-title"><span>Who's Watching?</span></h1>
              <div className="netflix-profiles">
                <button className="netflix-profile" style={{ animationDelay: "0.1s" }} onClick={() => onEnter("Guest")}>
                  <div className="netflix-avatar guest-avatar"><FaCompass /></div><span>Guest</span>
                </button>
                <button className="netflix-profile" style={{ animationDelay: "0.2s" }} onClick={() => setFormType("login")}>
                  <div className="netflix-avatar login-avatar"><FaUserShield /></div><span>Login</span>
                </button>
                <button className="netflix-profile" style={{ animationDelay: "0.3s" }} onClick={() => setFormType("signup")}>
                  <div className="netflix-avatar signup-avatar"><FaUserPlus /></div><span>Create Profile</span>
                </button>
              </div>
            </div>
          ) : (
            <form className="entry-form" onSubmit={submitForm}>
              <button className="back-choice" type="button" onClick={() => { setFormType(""); setName(""); setEmail(""); setPassword(""); setConfirmPassword(""); setMessage(""); }}>
                ← Back
              </button>
              <div className="form-icon">{formType === "login" ? <FaUserShield /> : <FaUserPlus />}</div>
              <p className="entry-kicker">BEATFLIX PROFILE</p>
              <h1>{formType === "login" ? "Welcome back." : "Create your profile."}</h1>
              <p className="form-description">
                {formType === "login" ? "Enter your details and continue discovering movies made for your mood." : "Create your BeatFlix profile and start building a more personal movie experience."}
              </p>

              <label>{formType === "login" ? "Email or Username" : "Username"}
                <div className="input-box">
                  <span className="input-icon"><FaUser /></span>
                  <input value={name} onChange={(e) => setName(e.target.value)} placeholder={formType === "login" ? "Enter email or username" : "Choose a username"} autoFocus />
                </div>
              </label>

              {formType === "signup" && (
                <label>Email
                  <div className="input-box">
                    <span className="input-icon"><FaEnvelope /></span>
                    <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} placeholder="Enter your email" />
                  </div>
                </label>
              )}

              <label>Password
                <div className="input-box">
                  <span className="input-icon"><FaLock /></span>
                  <input type={showPassword ? "text" : "password"} value={password} onChange={(e) => setPassword(e.target.value)} placeholder="Password" />
                  <button type="button" className="password-toggle" onClick={() => setShowPassword(!showPassword)}>{showPassword ? <FaEyeSlash /> : <FaEye />}</button>
                </div>
              </label>

              {formType === "signup" && (
                <label>Confirm Password
                  <div className="input-box">
                    <span className="input-icon"><FaLock /></span>
                    <input type={showConfirmPassword ? "text" : "password"} value={confirmPassword} onChange={(e) => setConfirmPassword(e.target.value)} placeholder="Confirm Password" />
                    <button type="button" className="password-toggle" onClick={() => setShowConfirmPassword(!showConfirmPassword)}>{showConfirmPassword ? <FaEyeSlash /> : <FaEye />}</button>
                  </div>
                </label>
              )}

              {message && <p className="entry-message">{message}</p>}

              <button className="enter-button" type="submit">
                {loading ? "Please wait..." : formType === "login" ? "Enter BeatFlix" : "Create Profile"} <FaArrowRight />
              </button>
              
              <div className="entry-divider"><span></span><p>OR</p><span></span></div>
              
              <button type="button" className="google-button" onClick={handleGoogleLogin}><FaGoogle /> Continue with Google</button>
              
              {formType === "login" && (
                <button type="button" className="forgot-password" onClick={() => { setForgotEmail(""); setMessage(""); setShowForgotModal(true); }}>
                  Forgot Password?
                </button>
              )}
              <p className="demo-note">Your BeatFlix profile is securely stored for a personalized movie experience.</p>
            </form>
          )}
        </section>
      </div>

      {/* 3. YOUR EXACT MODALS */}
      {showSuccess && (
        <div className="success-overlay">
          <div className="success-card">
            <div className="success-check">✓</div>
            <h2>Profile Created!</h2><p>Your BeatFlix account is ready.</p><span>Redirecting to Login...</span>
          </div>
        </div>
      )}

      {showOtpModal && (
        <div className="otp-overlay">
          <div className="otp-card">
            <h2>Email Verification</h2><p>We sent a 6-digit verification code to</p><strong>{email}</strong>
            <input className="otp-input" value={otp} onChange={(e) => setOtp(e.target.value)} placeholder="Enter OTP" maxLength={6} />
            <button className="enter-button" type="button" onClick={verifyAndRegister}>{loading ? "Verifying..." : "Verify OTP"}</button>
          </div>
        </div>
      )}

      {showForgotModal && (
        <div className="otp-overlay">
          <div className="otp-card">
            <h2>Forgot Password</h2><p>Enter the email associated with your BeatFlix account.</p>
            <input className="otp-input" type="email" placeholder="Enter your email" value={forgotEmail} onChange={(e) => setForgotEmail(e.target.value)} style={{ letterSpacing: "normal", fontSize: "16px", textAlign: "left" }} />
            <button className="enter-button" type="button" onClick={sendForgotOtp}>{loading ? "Sending..." : "Send OTP"}</button>
            <button type="button" className="back-choice" onClick={() => setShowForgotModal(false)}>Cancel</button>
          </div>
        </div>
      )}
    </main>
  );
}

export default EntryScreen;